var AV={papa:"img/avatars/papa.jpg",gas:"img/avatars/gas.jpg",br:"img/avatars/br.jpg"};
var C={
 papa:{n:"PAPA Personal",i:"LS",bg:"#8a3b12",s:"",m:[]},
 gas:{n:"Gasparina",i:"G",bg:"#3f7d4e",s:"en línea",m:[["La trampa","00:34"]]},
 br:{n:"Br",i:"B",bg:"#c98a5a",s:"",m:[["Y tu","00:33"]]},
 neg:{n:"Negocio 2024 contador",i:"N",bg:"#b8862b",s:"",m:[]}
};
var cur=null,$=function(i){return document.getElementById(i)};
var TK='<svg class="tick" viewBox="0 0 24 24"><path d="M1 13l4 4L14 7M9 15l2 2L21 7"/></svg>';
function esc(t){var d=document.createElement("div");d.textContent=t;return d.innerHTML}
function bub(t,h,inc){var d=document.createElement("div");d.className="m"+(inc?" in":"");d.innerHTML="<span>"+esc(t)+"</span><small>"+h+(inc?"":TK)+"</small>";$("ms").appendChild(d);$("ms").scrollTop=1e9}
function open(k){
 cur=k;var c=C[k];$("cn").textContent=c.n;$("cs").textContent=c.s;
 var a=$("cav");a.style.background=c.bg;if(AV[k])a.innerHTML='<img src="'+AV[k]+'">';else a.textContent=c.i;
 var ms=$("ms");[].slice.call(ms.querySelectorAll(".m")).forEach(function(e){e.remove()});
 c.m.forEach(function(m){bub(m[0],m[1],m[2])});
 if(k=="papa"&&!$("in").value)$("in").value="Hola, quiero hacer un pedido";
 else if(k!="papa")$("in").value="";
 $("home").classList.remove("on");$("chat").classList.add("on");
}
function go(k){
 if(k=="br"){
  if(!C.br.j){C.br.j=1;var d=new Date(),h=("0"+d.getHours()).slice(-2)+":"+("0"+d.getMinutes()).slice(-2);
   C.br.m.push(["Te la creistes celosa",h,1]);$("pb").textContent="Te la creistes celosa";$("pb").previousElementSibling.style.display="none"}
  open("br");if(!C.br.z){C.br.z=1;setTimeout(function(){$("pop").classList.add("on")},1800)}return}
 $("ld").classList.add("on");
 setTimeout(function(){$("ld").classList.remove("on");open("papa")},1500);
}
[].forEach.call(document.querySelectorAll(".row"),function(r){r.onclick=function(){go(r.dataset.c)}});
$("bk").onclick=function(){$("chat").classList.remove("on");$("home").classList.add("on")};
$("ban").querySelector(".x").onclick=function(e){e.stopPropagation();$("ban").style.display="none"};
function send(){
 var v=$("in").value.trim();if(!v)return;
 var d=new Date(),h=("0"+d.getHours()).slice(-2)+":"+("0"+d.getMinutes()).slice(-2);
 C[cur].m.push([v,h]);bub(v,h);$("in").value="";
 if(cur=="gas")$("pg").textContent=v;if(cur=="br")$("pb").textContent=v;
}
$("sd").onclick=send;
$("in").onkeydown=function(e){if(e.key=="Enter")send()};
[].forEach.call(document.querySelectorAll(".row"),function(r){var k=r.dataset.c;if(AV[k])r.querySelector(".av").innerHTML='<img src="'+AV[k]+'">'});
if(location.hash=="#papa")go("papa");
